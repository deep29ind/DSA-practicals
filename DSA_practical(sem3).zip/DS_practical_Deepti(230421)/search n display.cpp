#include <iostream>
using namespace std;


class My_array{
	private:
		int size;
		int arr[];
	public: 
		My_array(int a){
			size = a;
		}
		void Insert();
		void Delete();
		int Search(int d);
		void Display() const;
};

void My_array::Display () const{
	cout<<"\nArray Elements: "<<endl;
	for(int i = 0; i < size; i++){
		cout<<arr[i]<<" ";
	}
}

void My_array :: Insert(){
	int elem;
	for(int i = 0; i < size; i++){
		cout<<"Enter your elements: ";
		cin>>elem;
		arr[i] = elem;
	}

	Display();
		

/*	int choice,num,index;
	cout<<"(1) Insert at the beggining (2) Insert at the end (3) Insert at a specified index: ";
	cin>>choice;
	
	switch(choice){
		case 1: cout <<"Enter the number that you want to add (at the beggining): ";
				cin>>num;
				arr[0] = num;
				break;
		case 2: cout <<"Enter the number that you want to add (at the end): ";
				cin>>num;
				arr[size] = num;
				break;
		case 3: cout <<"Enter the number that you want to add : ";
				cin>>num;
				cout<<"At which index: ";
				cin>>index;
				arr[index] = num;
				break;
		default:
			cout<<"Err";
			break;
	}
*/


}

void My_array :: Delete(){
	int ind;
	cout<<"At which index you want to delete: ";
	cin>>ind;
	arr[ind] = 0;
	Display();
}

int My_array :: Search(int d){	
	
	for(int i = 0; i < size; ++i){
		if (arr[i] == d){
			return i;
			Display();		
		}
		else{
			return -1;
		}
	}
		
}

int main(){
	int a,d,result;
	cout<<"Choose the size of the array: ";
	cin>>a;
	My_array t(a);
	t.Insert();

	
	cout<<"\n\nType the number that you're looking for: ";
	cin>>d;
	result == -1 
		? cout<<"The element is not present in the array" 
		:cout<<"The element is at index "<<result;
	
	
	return 0;
	
}
