#include <iostream>
using namespace std;
class Stack{
	int size;
	int Top;
	int *S;
	public:
		Stack(){
			size=0;
			Top=-1;
			S=new int[size];
		}
		Stack(int size){
			this->size=size;
			Top=-1;
			S=new int[this->size];
		}
		void push(int x);
		int pop();
		int stackTop();
		int isEmpty();
		int isFull();
		void display();
};
void Stack::push(int x){
	if(Top==size-1)
	  cout<<"Stack is full"<<endl;
	else{
		Top++;
		S[Top]=x;
	}
}
int Stack::pop(){
	int x=-1;
	if(Top==-1)
	  cout<<"Stack is empty"<<endl;
	else{
		x=S[Top];
		Top--;
	}
	return x;
}
int Stack::stackTop(){
	if(Top==-1)
	   return -1;
	else
	   return S[Top];
}
int Stack::isEmpty(){
	if(Top==-1)
      return 1;
    else
      return 0;
}
int Stack::isFull(){
	if(Top==size-1)
	  return 1;
	else
	  return 0;
}
void Stack::display(){
	for(int i=Top;i>=0;i--){
		cout<<S[i]<<" ";
	}
	cout<<endl;
}

int main() {
    int var;
    cout << "Enter the size of the stack: ";
    cin >> var;
    Stack st(var);
    int choice, value;

    do {
        // Menu-driven options
        cout << "\nMenu: \n";
        cout << "1. Push an element\n";
        cout << "2. Pop an element\n";
        cout << "3. Display stack\n";
        cout << "4. Check if stack is empty\n";
        cout << "5. Check if stack is full\n";
        cout << "6. View top element\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter the value to push: ";
                cin >> value;
                st.push(value);
                break;

            case 2:
                value = st.pop();
                if (value != -1)
                    cout << "Popped value: " << value << endl;
                break;

            case 3:
                st.display();
                break;

            case 4:
                if (st.isEmpty())
                    cout << "Stack is empty." << endl;
                else
                    cout << "Stack is not empty." << endl;
                break;

            case 5:
                if (st.isFull())
                    cout << "Stack is full." << endl;
                else
                    cout << "Stack is not full." << endl;
                break;

            case 6:
                value = st.stackTop();
                if (value == -1)
                    cout << "Stack is empty." << endl;
                else
                    cout << "Top element: " << value << endl;
                break;

            case 7:
                cout << "Exiting the program." << endl;
                break;

            default:
                cout << "Invalid choice! Please try again." << endl;
        }

    } while (choice != 7);  // Exit the loop when the user selects option 7

    return 0;
}
