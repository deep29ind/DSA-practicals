#include <iostream>
using namespace std;

int rec_Fact(int n){
	if(n <= 1){
		return 1;
	}
	
	else{
		return n*rec_Fact(n-1);
	}
}
int main(){
	
	cout<<"Calculate the Factorial of 5 ";
	cout<<rec_Fact(5);
	
	return 0;

}
