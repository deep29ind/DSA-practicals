#include <iostream>
using namespace std;

const int MAX = 5;

class Stack {
private:
	int top;
public:
	Stack() {
		top = -1;
	}
	int arr[MAX];
	int data;

	void Push(char data);
	void Print();
	void Pop();
	int Top();

};

void Stack::Push(char data) {
	if (top == MAX - 1) {
		cout << "Stack is full" << endl;
		return;
	}
	top = top + 1;
	arr[top] = data;
}

void Stack::Pop() {
	if (top == -1) {
		cout << "Stack is empty" << endl;
		return;
	}
	top = top - 1;

}

int Stack::Top() {
	if (top == -1) {
		cout << "Stack is empty" << endl;
		exit(1);
	}

	return top;
}

void Stack::Print() {
	if (top == -1) {
		cout << "Stack is empty"<<endl;
		return;
	}
	cout << "Stack elements: " << endl;
	for (int i = 0; i <= top; i++) {
		cout << arr[i] << " ";
	}

}

int main() {
	Stack s;
	int e;
	char d;
	
	cout<<"How many elements do you want to add: ";
	cin>>e;
	for(int i = 0; i < e; i++){
		cout<<"Enter element ["<<i+1<<"]: ";
		cin>>d;
		s.Push(d);
	}
	s.Print();


	return 0;
}

//	s.Push(10);
//	s.Push(20);
//	s.Push(30);
//	//s.Pop();
//	s.Print();
//	cout << "\nThe Stack has " << s.Size() << " elements"<<endl;
//	cout<<"Topmost value is at index "<<s.Top()<<endl;
//	cout << "Is the Stack empty: " << s.Empty() << endl;

