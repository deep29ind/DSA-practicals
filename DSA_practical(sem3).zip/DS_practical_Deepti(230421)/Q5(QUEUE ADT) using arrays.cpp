#include <iostream>
using namespace std;
class Queue{
		int front;
		int rear;
		int size;
		int *q;
	public:
		Queue(){  //default constructor
			front=-1;
			rear=-1;
			size=0;
			q=new int[size];
		}
		Queue(int size){ //parameterized constructor
			front=-1;
			rear=-1;
			this->size=size;
			q=new int[this->size];
		}
			void enqueue(int x);
			int dequeue();
			bool isEmpty();
			void Front();
			int Size();
			void display();
		
};
void Queue::enqueue(int x){
	if(rear==size-1)
	   cout<<"Queue is full"<<endl;
	else{
		rear++;
		q[rear]=x;
	}
}
int Queue::dequeue(){
	int x=-1;
	if(rear==front)
	   cout<<"Queue is empty"<<endl;
    else{
    	x=q[front+1];
    	front++;
	}
	return x;
}
bool Queue::isEmpty(){
	if(front==rear)
	   return true;
	return false;
	}

void Queue::Front(){
	cout<<q[0];
	
}
int Queue::Size(){
	return size;
}
void Queue::display(){
	for(int i=front+1;i<=rear;i++){
		cout<<q[i]<<" ";
	}
	cout<<endl;
}
int main() {
    int size;
    cout << "Enter the size of the queue: ";
    cin >> size;
    Queue Q(size);

    int choice, value;

    do {
        // Menu-driven options
        cout << "\nMenu: \n";
        cout << "1. Enqueue an element\n";
        cout << "2. Dequeue an element\n";
        cout << "3. Display the queue\n";
        cout << "4. Display the front element\n";
        cout << "5. Display the size of the queue\n";
        cout << "6. Check if the queue is empty\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter the value to enqueue: ";
                cin >> value;
                Q.enqueue(value);
                break;

            case 2:
                value = Q.dequeue();
                if (value != -1)
                    cout << "Dequeued value: " << value << endl;
                break;

            case 3:
                Q.display();
                break;

            case 4:
                Q.Front();
                break;

            case 5:
                cout << "Size of the queue: " << Q.Size() << endl;
                break;

            case 6:
                if (Q.isEmpty())
                    cout << "Queue is empty" << endl;
                else
                    cout << "Queue is not empty" << endl;
                break;

            case 7:
                cout << "Exiting the program." << endl;
                break;

            default:
                cout << "Invalid choice! Please try again." << endl;
        }

    } while (choice != 7);  // Exit the loop when the user selects option 7

    return 0;
}

