#include <iostream>
using namespace std;

class Sort{
	private:
		int size;
		int arr[];
	public:
		Sort(int a){
			size = a;
		}
		void Display();
		void Add_elem();
		void Bubble_sort();
		void Insertion_sort();
		
};
	
void Sort :: Display() {
	cout<<"\nArray Elements: "<<endl;
	for(int i = 0; i < size; i++){
		cout<<arr[i]<<" ";
	}
}
void Sort :: Add_elem() {
	int elem;
	for(int i = 0; i < size; i++){
		cout<<"Enter your elements: ";
		cin>>elem;
		arr[i] = elem;
	}

}
void Sort :: Bubble_sort(){
	    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    cout<<"\nSorted Array: "<<endl;
	Display();
}

void Sort :: Insertion_sort(){
	for (int i = 1; i < size; ++i) {
        int key = arr[i];
        int j = i - 1; 
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
    
    cout<<"\nSorted Array: "<<endl;
	Display();
	
}


int main(){
	int a;
	cout<<"Choose the size: ";
	cin>>a;
	
	Sort t(a);
	t.Add_elem();
	//t.Bubble_sort();
	t.Insertion_sort();
	
	return 0;
	
}
