#include <iostream>
using namespace std;

class Node{
public:
	int data;
	Node *next;

	Node(){
		data = 0;
		next = NULL;
	}	
	
	Node(int data){
		this->data = data;
		this->next = NULL;
	}
};

class Circular_LL{
	public:
		Node *tail;
		
		Circular_LL(){
			tail = NULL;
		}
		
		void insertatbeg(int data);
		void insertatend(int data);
		void insertatbet(int data, int node);
		void deleteatbeg();
		void deleteatend();
		void deleteatanyposition(int node);
};

void Circular_LL :: insertatbeg(int data){
	Node *newNode = new Node(data);
	if(tail == NULL){
		tail = newNode;
		tail->next = newNode;
		return;
	}
	
	newNode->next = tail->next;
	tail->next = newNode;
}

void Circular_LL :: insertatend(int data){
	Node *newNode = new Node(data);
	if(tail == NULL){
		tail = newNode;
		tail->next = newNode;
		return;
	}
	
	newNode->next = tail->next;
	tail->next = newNode;
	tail = newNode;
}

void Circular_LL::insertatbet(int data, int node){
	Node* newNode = new Node(data);
	Node* temp = tail ->next;
	while( temp ->data != node){
		temp = temp -> next;
	}
	newNode -> next = temp -> next;
	temp -> next = newNode;
	
}

void Circular_LL::deleteatbeg(){
	Node* temp = tail -> next;
	tail -> next = temp -> next;
	delete temp;
}

void Circular_LL::deleteatend(){
	Node* temp1 = tail;
	Node* temp = tail;
	while(temp -> next != tail){
		temp = temp ->next;
	}
	temp ->next = tail -> next;
	tail = temp;
	delete temp1;
}

void Circular_LL :: deleteatanyposition(int node){
	
}
int main(){
	Circular_LL list;
	list.insertatbeg(10);
	list.insertatbeg(20);
	list.insertatbeg(30);
	list.insertatbeg(40);
	list.insertatbeg(50);
	list.insertatbeg(60);
	list.insertatbeg(70);
	list.insertatend(90);
	list.insertatbet(100, 50);
	list.insertatbet(200, 100);
	list.deleteatbeg();
	list.deleteatbeg();
	list.deleteatend();
	list.deleteatend();
	
	
	Node *temp = list.tail->next;
	do{
		cout<<temp->data<<" -> ";
		temp = temp->next;
	}while(temp!= list.tail->next);
	
	cout<<"NULL";
	
	return 0;
}
