#include <iostream>
using namespace std;

class Node {
public:
    int key;
    Node* left;
    Node* right;

    Node(int value) {
        key = value;
        left = nullptr;
        right = nullptr;
    }
};

class BST {
private:
    Node* root;

    Node* insert(Node* node, int key) {
        if (node == nullptr)
            return new Node(key);

        if (key < node->key)
            node->left = insert(node->left, key);
        else if (key > node->key)
            node->right = insert(node->right, key);

        return node;
    }

    Node* deleteNode(Node* node, int key) {
        if (node == nullptr) return node;

        if (key < node->key)
            node->left = deleteNode(node->left, key);
        else if (key > node->key)
            node->right = deleteNode(node->right, key);
        else {
            if (node->left == nullptr) {
                Node* temp = node->right;
                delete node;
                return temp;
            }
            if (node->right == nullptr) {
                Node* temp = node->left;
                delete node;
                return temp;
            }

            Node* temp = inOrderSuccessor(node->right);
            node->key = temp->key;
            node->right = deleteNode(node->right, temp->key);
        }

        return node;
    }

    Node* inOrderSuccessor(Node* node) {
        Node* current = node;
        while (current && current->left != nullptr)
            current = current->left;
        return current;
    }

    Node* search(Node* node, int key) {
        if (node == nullptr || node->key == key)
            return node;

        if (key < node->key)
            return search(node->left, key);

        return search(node->right, key);
    }

    void inOrder(Node* node) {
        if (node != nullptr) {
            inOrder(node->left);
            cout << node->key << " ";
            inOrder(node->right);
        }
    }

    void preOrder(Node* node) {
        if (node != nullptr) {
            cout << node->key << " ";
            preOrder(node->left);
            preOrder(node->right);
        }
    }

    void postOrder(Node* node) {
        if (node != nullptr) {
            postOrder(node->left);
            postOrder(node->right);
            cout << node->key << " ";
        }
    }

public:
    BST() {
        root = nullptr;
    }

    void insert(int key) {
        root = insert(root, key);
    }

    void deleteNode(int key) {
        root = deleteNode(root, key);
    }

    bool search(int key) {
        return search(root, key) != nullptr;
    }

    void displayInOrder() {
        inOrder(root);
        cout << endl;
    }

    void displayPreOrder() {
        preOrder(root);
        cout << endl;
    }

    void displayPostOrder() {
        postOrder(root);
        cout << endl;
    }

    void bulkInsert() {
        int n, key;
        cout << "Enter the number of nodes to insert: ";
        cin >> n;

        for (int i = 0; i < n; i++) {
            cout << "Enter node " << (i + 1) << ": ";
            cin >> key;
            insert(key);
        }
    }
};

int main() {
    BST bst;
    int choice, key;

    do {
        cout << "\nBinary Search Tree Operations:\n";
        cout << "1. Insert multiple elements\n2. Delete an element\n3. Search for an element\n";
        cout << "4. Display elements in In-Order\n5. Display elements in Pre-Order\n";
        cout << "6. Display elements in Post-Order\n7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            bst.bulkInsert();
            break;
        case 2:
            cout << "Enter element to delete: ";
            cin >> key;
            bst.deleteNode(key);
            break;
        case 3:
            cout << "Enter element to search: ";
            cin >> key;
            if (bst.search(key))
                cout << "Element " << key << " is found in the BST.\n";
            else
                cout << "Element " << key << " is not found in the BST.\n";
            break;
        case 4:
            cout << "BST in In-Order Traversal: ";
            bst.displayInOrder();
            break;
        case 5:
            cout << "BST in Pre-Order Traversal: ";
            bst.displayPreOrder();
            break;
        case 6:
            cout << "BST in Post-Order Traversal: ";
            bst.displayPostOrder();
            break;
        case 7:
            cout << "Exiting...\n";
            break;
        default:
            cout << "Invalid choice! Please try again.\n";
        }
    } while (choice != 7);

    return 0;
}
