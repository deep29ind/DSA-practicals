#include <iostream>
using namespace std;
// Display function 
void Display(int n, int array[]) {
    cout << "Array: ";
    for (int i = 0; i < n; i++) {
        cout << array[i] << " ";
    }
    cout << endl;
}
// insert Function
void Insert(int size, int &n, int array[]) {
    while (true) {
        int c;
        cout << "1. Insert at start\n2. Insert at last\n3. Insert at any position\n4. Exit\nEnter your choice:";
        cin >> c;
        switch (c) {
            case 1: {
                int k;
                cout << "Enter key: ";
                cin >> k;
                for (int i = n - 1; i >= 0; i--) {
                    array[i + 1] = array[i];
                }
                array[0] = k;
                n++;
                break;
            }
            case 2: {
                int k;
                cout << "Enter key: ";
                cin >> k;
                array[n] = k;
                n++;
                break;
            }
            case 3: {
                int k, index;
                cout << "Enter key: ";
                cin >> k;
                cout << "Position where to enter (0 to " << n << "): ";
                cin >> index;
                for (int i = n - 1; i >= index; i--) {
                    array[i + 1] = array[i];
                }
                array[index] = k;
                n++;
                break;
            }
            default:
                return;
        }
        Display(n, array);
    }
}
// delete function
void Delete(int size, int &n, int array[]) {
    while (true) {
        int c;
        cout << "1. Delete from start\n2. Delete from last\n3. Delete from any position\n4. Exit\nEnter your choice: ";
        cin >> c;
        switch (c) {
            case 1: {
                for (int i = 0; i < n - 1; i++) {
                    array[i] = array[i + 1];
                }
                n--;
                break;
            }
            case 2: {
                n--;
                break;
            }
            case 3: {
                int index;
                cout << "Position where to delete (0 to " << n - 1 << "): ";
                cin >> index;
                for (int i = index; i < n - 1; i++) {
                    array[i] = array[i + 1];
                }
                n--;
                break;
            }
            default:
                return;
        }
        Display(n, array); 
    }
}
// Search function
void Search(int size, int n, int array[]) {
    int k;
    cout << "Enter key to search: ";
    cin >> k;
    bool found = false;
    for (int i = 0; i < n; i++) {
        if (array[i] == k) {
            cout << "Element found at index " << i << endl;
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Element not found." << endl;
    }
}
// Insertion sort
void InsertionSort(int s, int arr[]) {
    for (int i = 1; i < s; i++) {
        int temp = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > temp) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = temp;
    }
    cout<<"Using Insertion sort-";
    Display(s, arr); 
}
// Bubble sort
void BubbleSort(int s, int arr[]) {
    for (int j = 0; j < s - 1; j++) {
        for (int i = 0; i < s - 1 - j; i++) {
            if (arr[i] > arr[i + 1]) {
                int temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;
            }
        }
    }
    cout<<"Using Bubble sort-";
    Display(s, arr); 
}
void SelectionSort(int s, int arr[]) {
    for (int i = 0; i < s - 1; i++) {
        int min_index = i;
        for (int j=i+1; j < s; j++) {
            if(arr[j]<arr[min_index]){
                min_index = j;
            }
        }
        if (min_index != i) {
            int temp = arr[i];
            arr[i] = arr[min_index];
            arr[min_index] = temp;
        }
    }
    cout << "Using selection sort-";
    Display(s, arr);
}
int main() {
    int size;
    cout << "Enter the size of array: ";
    cin >> size;
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;
    int array[size];
    cout << "Enter elements: ";
    for (int i = 0; i < n; i++) {
        cin >> array[i];
    }
    Insert(size, n, array);
    Delete(size, n, array);
    Search(size, n, array);
    Display(n, array);
    BubbleSort(n, array);
    InsertionSort(n, array);
    SelectionSort(n,array);
    return 0;
}
