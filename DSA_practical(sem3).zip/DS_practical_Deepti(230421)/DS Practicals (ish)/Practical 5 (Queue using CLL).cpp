#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int value) : data(value), next(nullptr) {}
};

class CircularQueue {
private:
    Node* front;
    Node* rear;

public:
    CircularQueue() : front(nullptr), rear(nullptr) {}

    void bulkInsert(int numElements) {
        for (int i = 0; i < numElements; i++) {
            int value;
            cout << "Enter value for element " << (i + 1) << ": ";
            cin >> value;
            enqueue(value);
        }
    }

    void enqueue(int value) {
        Node* newNode = new Node(value);
        if (front == nullptr) {
            front = rear = newNode;
            rear->next = front; // Make it circular
        } else {
            rear->next = newNode;
            rear = newNode;
            rear->next = front;
        }
    }

    void dequeue() {
        if (front == nullptr) {
            cout << "Queue is empty! Nothing to delete.\n";
            return;
        }
        if (front == rear) {
            cout << "Deleted element: " << front->data << "\n";
            delete front;
            front = rear = nullptr;
        } else {
            Node* temp = front;
            cout << "Deleted element: " << front->data << "\n";
            front = front->next;
            rear->next = front; // Maintain circular connection
            delete temp;
        }
    }

    void display() {
        if (front == nullptr) {
            cout << "Queue is empty.\n";
            return;
        }
        cout << "Queue elements: ";
        Node* temp = front;
        do {
            cout << temp->data << " ";
            temp = temp->next;
        } while (temp != front);
        cout << "\n";
    }
};

int main() {
    CircularQueue queue;
    int choice, numElements;

    do {
        cout << "\nMenu:\n";
        cout << "1. Insert Elements\n";
        cout << "2. Delete\n";
        cout << "3. Display\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter the number of elements to insert: ";
                cin >> numElements;
                queue.bulkInsert(numElements);
                break;
            case 2:
                queue.dequeue();
                break;
            case 3:
                queue.display();
                break;
            case 4:
                cout << "Exiting program.\n";
                break;
            default:
                cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 4);

    return 0;
}
