#include <iostream>
#include <cstring> // For strlen()
#include <cctype>  // For isdigit()
using namespace std;

#define MAX 100

struct StackArray {
    int stack[MAX];
    int top;

    StackArray() {
        top = -1;
    }

    bool empty() {
        return top == -1;
    }

    int size() {
        return top + 1;
    }

    void push(int value) {
        if (top >= MAX - 1) {
            cout << "Stack overflow!\n";
            return;
        }
        stack[++top] = value;
    }

    int pop() {
        if (empty()) {
            cout << "Stack underflow!\n";
            return -1;
        }
        return stack[top--];
    }

    int peek() {
        if (empty()) {
            cout << "Stack is empty!\n";
            return -1;
        }
        return stack[top];
    }
};

int evaluatePostfix(const char* expression) {
    StackArray stack;
    for (int i = 0; i < strlen(expression); i++) {
        char ch = expression[i];

        if (isdigit(ch)) {
            stack.push(ch - '0'); // Convert character to integer
        } else {
            int val2 = stack.pop();
            int val1 = stack.pop();

            switch (ch) {
                case '+': stack.push(val1 + val2); break;
                case '-': stack.push(val1 - val2); break;
                case '*': stack.push(val1 * val2); break;
                case '/': stack.push(val1 / val2); break;
                default: cout << "Invalid operator: " << ch << endl;
            }
        }
    }
    return stack.pop();
}

int evaluatePrefix(const char* expression) {
    StackArray stack;
    for (int i = strlen(expression) - 1; i >= 0; i--) {
        char ch = expression[i];

        if (isdigit(ch)) {
            stack.push(ch - '0'); // Convert character to integer
        } else {
            int val1 = stack.pop();
            int val2 = stack.pop();

            switch (ch) {
                case '+': stack.push(val1 + val2); break;
                case '-': stack.push(val1 - val2); break;
                case '*': stack.push(val1 * val2); break;
                case '/': stack.push(val1 / val2); break;
                default: cout << "Invalid operator: " << ch << endl;
            }
        }
    }
    return stack.pop();
}

int main() {
    int choice;
    char expression[100];

    do {
        cout << "\nMenu:\n";
        cout << "1. Evaluate Postfix Expression\n";
        cout << "2. Evaluate Prefix Expression\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter postfix expression: ";
                cin >> expression;
                cout << "Result: " << evaluatePostfix(expression) << endl;
                break;
            case 2:
                cout << "Enter prefix expression: ";
                cin >> expression;
                cout << "Result: " << evaluatePrefix(expression) << endl;
                break;
            case 3:
                cout << "Exiting program.\n";
                break;
            default:
                cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 3);

    return 0;
}
