#include <iostream>
using namespace std;

class Node {
public:
    int key;
    Node* left;
    Node* right;
    int height;

    Node(int value) {
        key = value;
        left = nullptr;
        right = nullptr;
        height = 1;
    }
};

class AVLTree {
private:
    int getHeight(Node* node) {
        return (node == nullptr) ? 0 : node->height;
    }

    int getBalanceFactor(Node* node) {
        return (node == nullptr) ? 0 : getHeight(node->left) - getHeight(node->right);
    }
    
    Node* rightRotate(Node* y) {
        Node* x = y->left;
        Node* T2 = x->right;
        x->right = y;
        y->left = T2;
        y->height = max(getHeight(y->left), getHeight(y->right)) + 1;
        x->height = max(getHeight(x->left), getHeight(x->right)) + 1;
        return x;
    }

    Node* leftRotate(Node* x) {
        Node* y = x->right;
        Node* T2 = y->left;
        y->left = x;
        x->right = T2;
        x->height = max(getHeight(x->left), getHeight(x->right)) + 1;
        y->height = max(getHeight(y->left), getHeight(y->right)) + 1;
        return y;
    }

    Node* insert(Node* node, int key) {
        if (node == nullptr) return new Node(key);
        if (key < node->key)
            node->left = insert(node->left, key);
        else if (key > node->key)
            node->right = insert(node->right, key);
        else
            return node;
        node->height = 1 + max(getHeight(node->left), getHeight(node->right));
        int balance = getBalanceFactor(node);
        if (balance > 1 && key < node->left->key) return rightRotate(node);
        if (balance < -1 && key > node->right->key) return leftRotate(node);
        if (balance > 1 && key > node->left->key) {
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }
        if (balance < -1 && key < node->right->key) {
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }
        return node;
    }

    bool search(Node* root, int key) {
        if (root == nullptr) return false;
        if (key == root->key) return true;
        if (key < root->key) return search(root->left, key);
        return search(root->right, key);
    }

    void inOrder(Node* root) {
        if (root != nullptr) {
            inOrder(root->left);
            cout << root->key << " ";
            inOrder(root->right);
        }
    }

public:
    Node* root;
    AVLTree() {
        root = nullptr;
    }
    void insert(int key) {
        root = insert(root, key);
    }
    bool search(int key) {
        return search(root, key);
    }
    void display() {
        inOrder(root);
        cout << endl;
    }
};

int main() {
    AVLTree avl;
    int choice, key, numNodes;
    do {
        cout << "\nAVL Tree Operations Menu:\n";
        cout << "1. Insert Multiple Nodes\n2. Search a Node\n3. Display In-Order Traversal\n4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1:
                cout << "Enter the number of nodes to insert: ";
                cin >> numNodes;
                cout << "Enter the nodes: ";
                for (int i = 0; i < numNodes; i++) {
                    cin >> key;
                    avl.insert(key);
                }
                break;

            case 2:
                cout << "Enter key to search: ";
                cin >> key;
                if (avl.search(key))
                    cout << "Key " << key << " is found in the tree.\n";
                else
                    cout << "Key " << key << " is not found in the tree.\n";
                break;

            case 3:
                cout << "AVL Tree (In-Order Traversal): ";
                avl.display();
                break;

            case 4:
                cout << "Exiting program...\n";
                break;

            default:
                cout << "Invalid choice! Please try again.\n";
        }
    } while (choice != 4);
    return 0;
}
