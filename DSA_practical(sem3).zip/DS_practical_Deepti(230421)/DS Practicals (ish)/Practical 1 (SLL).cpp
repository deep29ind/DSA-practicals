#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;
    
    Node() {
        data = 0;
        next = NULL;
    }
    
    Node(int data) {
        this->data = data;
        this->next = NULL;
    }
};

class SLL {
public:
    Node* head;

    SLL() {
        head = NULL;
    }

    // Display the list
    void display() {
        if (head == NULL) {
            cout << "List is empty!" << endl;
        } else {
            Node* temp = head;
            while (temp != NULL) {
                cout << temp->data << " ";
                temp = temp->next;
            }
            cout << endl;
        }
    }
    
    // Insert at the beginning
    void insertAtBeginning(int value){
        Node* newnode=new Node(value);
        newnode->next = head;
        head = newnode;
        display();
    }

    // Insert at the end
    void insertAtEnd(int value) {
        Node* newnode=new Node(value);
        if (head == NULL) {
            head = newnode;
        } else {
            Node* temp = head;
            while (temp->next!=NULL){
                temp = temp->next;
            }
            temp->next = newnode;
        }
        display();
    }

    // Insert at a specific position
    void insertAtPosition(int value, int position) {
        Node* newnode=new Node(value);
        if (position == 0) {
            insertAtBeginning(value);
        } else {
            Node* temp = head;
            for (int i=0;i<position-1 && temp!=NULL;i++) {
                temp = temp->next;
            }
            if (temp != NULL) {
                newnode->next=temp->next;
                temp->next = newnode;
            } else {
                cout <<"Invalid position!"<< endl;
            }
        }
        display ();
    }

    // Delete from the beginning
    void deleteFromBeginning() {
        if (head == NULL) {
            cout<<"List is empty!"<< endl;
        } else {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
        display ();
    }

    // Delete from the end
    void deleteFromEnd() {
        if (head == NULL) {
            cout << "List is empty!" << endl;
        } else if (head->next==NULL){
            delete head;
            head = NULL;
        } else {
            Node* temp = head;
            while (temp->next->next != NULL) {
                temp = temp->next;
            }
            delete temp->next;
            temp->next = NULL;
        }
        display ();
    }

    // Delete from a specific position
    void deleteFromPosition(int position) {
        if (head == NULL) {
            cout << "List is empty!" << endl;
            return;
        }
        if (position == 0) {
            deleteFromBeginning();
        } else {
            Node* temp = head;
            for (int i=0; i<position-1 && temp != NULL;i++){
                temp = temp->next;
            }
            if (temp!=NULL&& temp->next !=NULL) {
                Node* nodeToDelete = temp->next;
                temp->next = temp->next->next;
                delete nodeToDelete;
            } else {
                cout << "Invalid position!" << endl;
            }
        }
        display ();
    }

    // Search an element
    void search(int value) {
        Node* temp = head;
        int position = 0;
        while (temp != NULL) {
            if (temp->data == value) {
                cout << "Element found at position: " << position << endl;
                return;
            }
            temp = temp->next;
            position++;
        }
        cout << "Element not found!" << endl;
    }
};

int main() {
    SLL obj;
    int choice, value, position;

    do {
        cout << "1. Insert\n2. Delete\n3. Search\n4. Display\n5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            do {
                cout << "1.1 Insert at Beginning\n1.2 Insert at End\n1.3 Insert at Any Position\n1.4 Exit\n";
                cout << "Enter your choice: ";
                cin >> choice;

                if (choice == 1) {
                    cout << "Enter value to insert: ";
                    cin >> value;
                    obj.insertAtBeginning(value);
                } else if (choice == 2) {
                    cout << "Enter value to insert: ";
                    cin >> value;
                    obj.insertAtEnd(value);
                } else if (choice == 3) {
                    cout << "Enter value to insert: ";
                    cin >> value;
                    cout << "Enter position to insert: ";
                    cin >> position;
                    obj.insertAtPosition(value, position);
                }
            } while (choice != 4);
            break;

        case 2:
            do {
                cout << "2.1 Delete from Beginning\n2.2 Delete from End\n2.3 Delete from Any Position\n2.4 Exit\n";
                cout << "Enter your choice: ";
                cin >> choice;

                if (choice == 1) {
                    obj.deleteFromBeginning();
                } else if (choice == 2) {
                    obj.deleteFromEnd();
                } else if (choice == 3) {
                    cout << "Enter position to delete: ";
                    cin >> position;
                    obj.deleteFromPosition(position);
                }
            } while (choice != 4);
            break;

        case 3:
            cout << "Enter value to search: ";
            cin >> value;
            obj.search(value);
            break;

        case 4:
            obj.display();
            break;

        case 5:
            cout << "Exiting..." << endl;
            break;

        default:
            cout << "Invalid choice!" << endl;
        }

    } while (choice != 5);

    return 0;
}
