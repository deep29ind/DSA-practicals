#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int value) {
        data = value;
        next = NULL;
    }
};

class CircularLinkedList {
public:
    Node* tail;

    CircularLinkedList() {
        tail = NULL;
    }
    
    // Display the list
    void display() {
        if (tail == NULL) {
            cout << "List is empty!" << endl;
        } else {
            Node* temp = tail->next;
            do {
                cout << temp->data << " ";
                temp = temp->next;
            } while (temp != tail->next);
            cout << endl;
        }
    }
    
    // Insert at the beginning
    void insertAtBeginning(int value) {
        Node* newnode = new Node(value);
        if (tail == NULL) {
            tail = newnode;
            tail->next = tail;  // Point to itself to make it circular
        } else {
            newnode->next = tail->next;
            tail->next = newnode;
        }
        display();
    }

    // Insert at the end
    void insertAtEnd(int value) {
        Node* newnode = new Node(value);
        if (tail == NULL) {
            tail = newnode;
            tail->next = tail;  // Point to itself to make it circular
        } else {
            newnode->next = tail->next;
            tail->next = newnode;
            tail = newnode;
        }
        display();
    }

    // Insert at a specific position
    void insertAtPosition(int value, int position) {
        if (position == 0) {
            insertAtBeginning(value);
        } else {
            Node* temp = tail->next;
            Node* newnode = new Node(value);
            for (int i = 0; i < position - 1 && temp != tail; i++) {
                temp = temp->next;
            }
            newnode->next = temp->next;
            temp->next = newnode;
            if (temp == tail) {
                tail = newnode;
            }
        }
        display();
    }

    // Delete from the beginning
    void deleteFromBeginning() {
        if (tail == NULL) {
            cout << "List is empty!" << endl;
        } else if (tail->next == tail) {
            delete tail;
            tail = NULL;
        } else {
            Node* temp = tail->next;
            tail->next = temp->next;
            delete temp;
        }
        display();
    }

    // Delete from the end
    void deleteFromEnd() {
        if (tail == NULL) {
            cout << "List is empty!" << endl;
        } else if (tail->next == tail) {
            delete tail;
            tail = NULL;
        } else {
            Node* temp = tail->next;
            while (temp->next != tail) {
                temp = temp->next;
            }
            temp->next = tail->next;
            delete tail;
            tail = temp;
        }
        display();
    }
    
    //Delete from any position 
void deleteFromPosition(int position){
    if (tail == NULL) {
        cout << "List is empty!" << endl;
        return;
    }
    Node* temp = tail->next; 
    if (position == 0) {
        deleteFromBeginning();  
        return;
    }
    int count = 0;
    while (temp->next != tail->next && count < position - 1) {
        temp = temp->next;
        count++;
    }
    if (count != position - 1 || temp->next == tail->next) {
        cout << "Position out of bounds!" << endl;
        return;
    }
    Node* X = temp->next; 
    if (X == tail) {
        tail = temp; 
    }
    temp->next = X->next;
    delete X;
    display(); 
}

    // Search for an element
    void search(int value) {
        if (tail == NULL) {
            cout << "List is empty!" << endl;
            return;
        }
        Node* temp = tail->next;
        int position = 0;
        do {
            if (temp->data == value) {
                cout << "Element found at position: " << position << endl;
                return;
            }
            temp = temp->next;
            position++;
        } while (temp != tail->next);
        cout << "Element not found!" << endl;
    }

};

int main() {
    CircularLinkedList obj;
    int choice, sub_choice, value, position;

    do {
        cout << "Main Menu:\n1. Insert\n2. Delete\n3. Search\n4. Display\n5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            do {
                cout << "\nInsert Menu:\n1.1 Insert at Beginning\n1.2 Insert at End\n1.3 Insert at Any Position\n1.4 Exit Insert Menu\n";
                cout << "Enter your choice: ";
                cin >> sub_choice;

                switch (sub_choice) {
                    case 1:
                        cout << "Enter value to insert: ";
                        cin >> value;
                        obj.insertAtBeginning(value);
                        break;
                    case 2:
                        cout << "Enter value to insert: ";
                        cin >> value;
                        obj.insertAtEnd(value);
                        break;
                    case 3:
                        cout << "Enter value to insert: ";
                        cin >> value;
                        cout << "Enter position to insert: ";
                        cin >> position;
                        obj.insertAtPosition(value, position);
                        break;
                    case 4:
                        cout << "Exiting Insert Menu\n";
                        break;
                    default:
                        cout << "Invalid choice!\n";
                }
            } while (sub_choice != 4);
            break;

        case 2:
            do {
                cout << "\nDelete Menu:\n2.1 Delete from Beginning\n2.2 Delete from End\n2.3 Delete from Any Position\n2.4 Exit Delete Menu\n";
                cout << "Enter your choice: ";
                cin >> sub_choice;

                switch (sub_choice) {
                    case 1:
                        obj.deleteFromBeginning();
                        break;
                    case 2:
                        obj.deleteFromEnd();
                        break;
                    case 3:
                        cout << "Enter position to delete: ";
                        cin >> position;
                        obj.deleteFromPosition(position);
                        break;
                    case 4:
                        cout << "Exiting Delete Menu\n";
                        break;
                    default:
                        cout << "Invalid choice!\n";
                }
            } while (sub_choice != 4);
            break;

        case 3:
            cout << "Enter value to search: ";
            cin >> value;
            obj.search(value);
            break;

        case 4:
            obj.display();
            break;

        case 5:
            cout << "Exiting program...\n";
            break;

        default:
            cout << "Invalid choice!\n";
        }

    } while (choice != 5);

    return 0;
}
