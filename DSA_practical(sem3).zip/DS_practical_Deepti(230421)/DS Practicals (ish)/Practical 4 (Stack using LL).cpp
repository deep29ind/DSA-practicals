#include <iostream>
#include <cstring> // For strlen()
#include <cctype>  // For isdigit()
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int value) : data(value), next(nullptr) {}
};

class StackLinkedList {
private:
    Node* topNode;
    int count;

public:
    StackLinkedList() : topNode(nullptr), count(0) {}

    bool empty() {
        return topNode == nullptr;
    }

    int size() {
        return count;
    }

    void push(int value) {
        Node* newNode = new Node(value);
        newNode->next = topNode;
        topNode = newNode;
        count++;
    }

    int pop() {
        if (empty()) {
            cout << "Stack underflow!\n";
            return -1;
        }
        Node* temp = topNode;
        int value = topNode->data;
        topNode = topNode->next;
        delete temp;
        count--;
        return value;
    }

    int peek() {
        if (empty()) {
            cout << "Stack is empty!\n";
            return -1;
        }
        return topNode->data;
    }
};

int evaluatePostfix(const char* expression) {
    StackLinkedList stack;
    for (int i = 0; i < strlen(expression); i++) {
        char ch = expression[i];

        if (isdigit(ch)) {
            stack.push(ch - '0'); // Convert character to integer
        } else {
            int val2 = stack.pop();
            int val1 = stack.pop();

            switch (ch) {
                case '+': stack.push(val1 + val2); break;
                case '-': stack.push(val1 - val2); break;
                case '*': stack.push(val1 * val2); break;
                case '/': stack.push(val1 / val2); break;
                default: cout << "Invalid operator: " << ch << endl;
            }
        }
    }
    return stack.pop();
}

int evaluatePrefix(const char* expression) {
    StackLinkedList stack;
    for (int i = strlen(expression) - 1; i >= 0; i--) {
        char ch = expression[i];

        if (isdigit(ch)) {
            stack.push(ch - '0'); // Convert character to integer
        } else {
            int val1 = stack.pop();
            int val2 = stack.pop();

            switch (ch) {
                case '+': stack.push(val1 + val2); break;
                case '-': stack.push(val1 - val2); break;
                case '*': stack.push(val1 * val2); break;
                case '/': stack.push(val1 / val2); break;
                default: cout << "Invalid operator: " << ch << endl;
            }
        }
    }
    return stack.pop();
}

int main() {
    int choice;
    char expression[100];

    do {
        cout << "\nMenu:\n";
        cout << "1. Evaluate Postfix Expression\n";
        cout << "2. Evaluate Prefix Expression\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter postfix expression: ";
                cin >> expression;
                cout << "Result: " << evaluatePostfix(expression) << endl;
                break;
            case 2:
                cout << "Enter prefix expression: ";
                cin >> expression;
                cout << "Result: " << evaluatePrefix(expression) << endl;
                break;
            case 3:
                cout << "Exiting program.\n";
                break;
            default:
                cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 3);

    return 0;
}
