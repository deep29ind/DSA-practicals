#include <iostream>
using namespace std;

class QueueArray {
private:
    int front, rear, capacity;
    int* queue;

public:
    QueueArray(int size) {
        capacity = size;
        queue = new int[capacity];
        front = rear = -1;
    }

    ~QueueArray() {
        delete[] queue;
    }

    void bulkInsert(int numElements) {
        for (int i = 0; i < numElements; i++) {
            int value;
            cout << "Enter value for element " << (i + 1) << ": ";
            cin >> value;
            enqueue(value);
        }
    }

    void enqueue(int value) {
        if ((rear + 1) % capacity == front) {
            cout << "Queue is full! Cannot insert " << value << ".\n";
            return;
        }
        if (front == -1) {
            front = rear = 0;
        } else {
            rear = (rear + 1) % capacity;
        }
        queue[rear] = value;
    }

    void dequeue() {
        if (front == -1) {
            cout << "Queue is empty! Nothing to delete.\n";
            return;
        }
        cout << "Deleted element: " << queue[front] << "\n";
        if (front == rear) {
            front = rear = -1;
        } else {
            front = (front + 1) % capacity;
        }
    }

    void display() {
        if (front == -1) {
            cout << "Queue is empty.\n";
            return;
        }
        cout << "Queue elements: ";
        int i = front;
        while (true) {
            cout << queue[i] << " ";
            if (i == rear) break;
            i = (i + 1) % capacity;
        }
        cout << "\n";
    }
};

int main() {
    int size, choice, numElements;
    cout << "Enter the size of the queue: ";
    cin >> size;
    QueueArray queue(size);

    do {
        cout << "\nMenu:\n";
        cout << "1. Insert Elements\n";
        cout << "2. Delete\n";
        cout << "3. Display\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter the number of elements to insert: ";
                cin >> numElements;
                queue.bulkInsert(numElements);
                break;
            case 2:
                queue.dequeue();
                break;
            case 3:
                queue.display();
                break;
            case 4:
                cout << "Exiting program.\n";
                break;
            default:
                cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 4);

    return 0;
}
